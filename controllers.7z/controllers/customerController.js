const db = require('../db');

// ACCOUNT OVERVIEW: List all loans for a customer
exports.getOverview = (req, res) => {
  const { customer_id } = req.params;

  // Step 1: Check if customer exists
  db.get(`SELECT * FROM Customers WHERE customer_id = ?`, [customer_id], (err, customer) => {
    if (err || !customer) {
      return res.status(404).json({ error: 'Customer not found or has no loans' });
    }

    // Step 2: Get all loans for this customer
    db.all(`SELECT * FROM Loans WHERE customer_id = ?`, [customer_id], (err, loans) => {
      if (err) return res.status(500).json({ error: err.message });

      if (loans.length === 0) {
        return res.status(404).json({ error: 'No loans found for this customer' });
      }

      const loanSummaries = [];

      let completed = 0;
      loans.forEach((loan) => {
        db.get(
          `SELECT SUM(amount) as amount_paid FROM Payments WHERE loan_id = ?`,
          [loan.loan_id],
          (err, row) => {
            const amount_paid = row?.amount_paid || 0;
            const total_interest = loan.total_amount - loan.principal_amount;
            const emis_left = Math.ceil(Math.max(loan.total_amount - amount_paid, 0) / loan.monthly_emi);

            loanSummaries.push({
              loan_id: loan.loan_id,
              principal: loan.principal_amount,
              total_amount: loan.total_amount,
              total_interest,
              emi_amount: loan.monthly_emi,
              amount_paid,
              emis_left,
            });

            completed++;
            if (completed === loans.length) {
              // Once all async queries complete, send response
              res.status(200).json({
                customer_id: customer.customer_id,
                total_loans: loans.length,
                loans: loanSummaries,
              });
            }
          }
        );
      });
    });
  });
};
