const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const {
  calculateInterest,
  calculateTotalAmount,
  calculateMonthlyEMI,
} = require('../utils/calculations');

// LEND: Create a new loan
exports.createLoan = (req, res) => {
  const { customer_id, loan_amount, loan_period_years, interest_rate_yearly } = req.body;

  if (!customer_id || !loan_amount || !loan_period_years || !interest_rate_yearly) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const interest = calculateInterest(loan_amount, loan_period_years, interest_rate_yearly);
  const total_amount = calculateTotalAmount(loan_amount, interest);
  const monthly_emi = calculateMonthlyEMI(total_amount, loan_period_years);
  const loan_id = uuidv4();

  db.run(
    `INSERT INTO Loans (loan_id, customer_id, principal_amount, total_amount, interest_rate, loan_period_years, monthly_emi, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      loan_id,
      customer_id,
      loan_amount,
      total_amount,
      interest_rate_yearly,
      loan_period_years,
      monthly_emi,
      'ACTIVE',
    ],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });

      res.status(201).json({
        loan_id,
        customer_id,
        total_amount_payable: total_amount,
        monthly_emi,
      });
    }
  );
};

// PAYMENT: Make a payment against a loan
exports.makePayment = (req, res) => {
  const { loan_id } = req.params;
  const { amount, payment_type } = req.body;

  if (!amount || !payment_type || !loan_id) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const payment_id = uuidv4();

  db.get(`SELECT * FROM Loans WHERE loan_id = ?`, [loan_id], (err, loan) => {
    if (err || !loan) {
      return res.status(404).json({ error: 'Loan not found' });
    }

    db.run(
      `INSERT INTO Payments (payment_id, loan_id, amount, payment_type) VALUES (?, ?, ?, ?)`,
      [payment_id, loan_id, amount, payment_type],
      function (err) {
        if (err) return res.status(500).json({ error: err.message });

        // Get total paid so far
        db.get(
          `SELECT SUM(amount) AS total_paid FROM Payments WHERE loan_id = ?`,
          [loan_id],
          (err, row) => {
            const total_paid = row?.total_paid || 0;
            const remaining_balance = Math.max(loan.total_amount - total_paid, 0);
            const emis_left = Math.ceil(remaining_balance / loan.monthly_emi);

            if (remaining_balance <= 0) {
              db.run(`UPDATE Loans SET status = 'PAID_OFF' WHERE loan_id = ?`, [loan_id]);
            }

            return res.status(200).json({
              payment_id,
              loan_id,
              message: 'Payment recorded successfully.',
              remaining_balance,
              emis_left,
            });
          }
        );
      }
    );
  });
};

// LEDGER: Get transaction history and current status
exports.getLedger = (req, res) => {
  const { loan_id } = req.params;

  db.get(`SELECT * FROM Loans WHERE loan_id = ?`, [loan_id], (err, loan) => {
    if (err || !loan) {
      return res.status(404).json({ error: 'Loan not found' });
    }

    db.all(
      `SELECT * FROM Payments WHERE loan_id = ? ORDER BY payment_date ASC`,
      [loan_id],
      (err, transactions) => {
        if (err) return res.status(500).json({ error: err.message });

        const total_paid = transactions.reduce((sum, tx) => sum + tx.amount, 0);
        const balance_amount = Math.max(loan.total_amount - total_paid, 0);
        const emis_left = Math.ceil(balance_amount / loan.monthly_emi);

        return res.status(200).json({
          loan_id: loan.loan_id,
          customer_id: loan.customer_id,
          principal: loan.principal_amount,
          total_amount: loan.total_amount,
          monthly_emi: loan.monthly_emi,
          amount_paid: total_paid,
          balance_amount,
          emis_left,
          transactions: transactions.map((tx) => ({
            transaction_id: tx.payment_id,
            date: tx.payment_date,
            amount: tx.amount,
            type: tx.payment_type,
          })),
        });
      }
    );
  });
};
